
open ImgUtil                                                                       //accessing library
let rec xfract bmp len (x,y) =                                                     //definition
  if len < 50 then setBox red (x, y) (x+len,y+len) bmp  
  else let thrd = len / 3
       xfract bmp thrd (x,y)
       xfract bmp thrd (x-thrd, y+thrd)
       xfract bmp thrd (x+thrd, y-thrd)
       xfract bmp thrd (x-thrd, y-thrd)
       xfract bmp thrd (x+thrd, y+thrd)                                           

do runSimpleApp "xfract" 600 600 (fun bmp -> xfract bmp 200 (300, 300) |> ignore)  //execution 

